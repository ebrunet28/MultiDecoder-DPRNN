1. Run the matlab scripts first(you can disable the 'max' option for mixing) to get 2, 3, 4, 5 spkr mixtures
2. Put preprocess2spkr under 2speakers/wav8k/min, and so on for 3, 4, 5 spkrs
3. Run the preprocess{}spkr files, then you should have 2spkr_json in the same folder with 2speakers. Same thing for 3, 4, 5 spkrs.